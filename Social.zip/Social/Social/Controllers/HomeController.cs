﻿using System.Globalization;
using IdentitySample.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity.EntityFramework;
using Social.ViewModel;
using System.Collections.Generic;

using System.Net;
using System.Data.Entity;
using Social.Models;
using System.Drawing;
using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
namespace IdentitySample.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        public HomeController()
        {
        }

        public HomeController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }
        private ApplicationSignInManager _signInManager;
        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set { _signInManager = value; }
        }


        private ApplicationRoleManager _roleManager;
        public ApplicationRoleManager RoleManager
        {
            get
            {
                return _roleManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationRoleManager>();
            }
            private set
            {
                _roleManager = value;
            }
        }
        private byte[] processImage(HttpPostedFileBase photo, ref byte[] imageData, string userid)
        {
            var filename = Path.GetFileName(photo.FileName);
            System.Drawing.Image savedFileName =
            System.Drawing.Image.FromStream(photo.InputStream);

            System.Drawing.Image savedFileName1 =
            System.Drawing.Image.FromStream(photo.InputStream);
            int width = 0;
            int height = 0;

            if (savedFileName.Width > 800)
                width = 800;
            else
                width = savedFileName.Width;

            if (savedFileName.Height>800)
                height = 800;
            else
                height=savedFileName.Width;

            imageData = new byte[photo.ContentLength];
            //photo.InputStream.Read(imageData, 0, photo.ContentLength);

            using (var srcImage1 = savedFileName)
            using (var newImage = new Bitmap(width, height))
            using (var graphics = Graphics.FromImage(newImage))

           
            using (var stream1 = new MemoryStream())
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                graphics.DrawImage(srcImage1, new Rectangle(0, 0, width, height));
                newImage.Save(stream1, ImageFormat.Png);
                var thumbNew = File(stream1.ToArray(), "image/png");
                imageData = thumbNew.FileContents;
            }



            //photo.SaveAs(savedFileName);




            //Save image to file
            //var filename = "MyDefaultImage." + Path.GetExtension(photo.FileName);
            //string Userpath = userid;
            //string filePathOriginalvirtuel = "/Content/" + Userpath + "/Uploads/Originals";
            //var filePathOriginal = Server.MapPath(filePathOriginalvirtuel);
            //string filePathThumbnailVirtual = "/Content/" + Userpath + "/Uploads/Thumbnails";
            //var filePathThumbnail = Server.MapPath(filePathThumbnailVirtual);
            //if (!Directory.Exists(filePathOriginal))
            //    Directory.CreateDirectory(filePathOriginal);
            //if (!Directory.Exists(filePathThumbnail))
            //    Directory.CreateDirectory(filePathThumbnail);
            //string savedFileName = Path.Combine(filePathOriginal, filename);
            //photo.SaveAs(savedFileName);

            //Read image back from file and create thumbnail from it
            // var imageFile = Path.Combine(Server.MapPath(filePathOriginalvirtuel), filename);
            using (var srcImage = savedFileName1)
            using (var newImage = new Bitmap(100, 100))
            using (var graphics = Graphics.FromImage(newImage))
            using (var stream = new MemoryStream())
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                graphics.DrawImage(srcImage, new Rectangle(0, 0, 100, 100));
                newImage.Save(stream, ImageFormat.Png);
                var thumbNew = File(stream.ToArray(), "image/png");
                return thumbNew.FileContents;
            }


        }

         [HttpPost]
        public JsonResult UploadImage(HttpPostedFileBase HelpSectionImages)
        {


            byte[] imageData = null;
            string userid = db.Users.Where(i => i.UserName == User.Identity.Name).SingleOrDefault().Id;
            byte[] Imagethumbnail = processImage(HelpSectionImages, ref imageData, userid);


            var photo = new Photos
            {
                PhotoName = HelpSectionImages.FileName,
                PhotoTitle = "My Shared Image",
                ImageMimeType = HelpSectionImages.ContentLength,
                ImageData = imageData,
                ProfilePhoto = false,
                UserId = userid,
                AddedDate = DateTime.UtcNow,
                Imagethumbnail = Imagethumbnail
            };
            db.Photos.Add(photo);
            db.SaveChanges();
            return Json(new
            {
                PhotoId = photo.Id.ToString()
            });

        }
        public ActionResult Index()
        {
          //  var user = User.Identity.Name;

            var user = db.Users
                .Include(i => i.Contacts)
                .Include(i => i.Messages)
                .Include(i => i.WallPosts)
                .Include(i => i.Photos)
                .Where(i => i.UserName == User.Identity.Name).SingleOrDefault();
            //var wallpost=db.WallPosts.Where(i=>i.UserId=u)
            //var comments=db.SocialComments
            //    .Where(i=>i.WallPostid=)

            string profilephotoid = GetProfileImageId(user.Photos);

            UserViewModel userviewmodel = new UserViewModel 
            {
                Email=user.Email,
                FirstName=user.FirstName,
                Id=user.Id,
                LastName=user.LastName,
                profileImageID = profilephotoid,
                TimeLineImageId = profilephotoid
            };

            return View(userviewmodel);

            //return PartialView()
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public string GetProfileImageId(ICollection<Photos> _Photos)
        {
            string profilephotoid = string.Empty;
            foreach (var photo in _Photos)
            {
                if (photo.ProfilePhoto == true)
                {
                    profilephotoid = photo.Id.ToString();
                    break;
                }
            }

            return profilephotoid;
        }
       public ICollection<UserFriends> convertToUserFriend(ICollection<Contacts> _Contacts)
        {
           List<UserFriends> friends=new List<UserFriends>();
           UserFriends fnd1= new UserFriends(), fnd2 = new UserFriends();
            foreach(Contacts friend in _Contacts)
            {

                if (friend.Followedid != null)
                {
                    fnd1.Id = friend.Followedid;

                    var user1 = db.Users.Where(i => i.Id == friend.Followedid).SingleOrDefault();
                    fnd1.Name = user1.FirstName;
                    fnd1.profileImageId = GetProfileImageId(user1.Photos);
                    friends.Add(fnd1);
                }
                //if (friend.Followedid != null)
                //{
                //    fnd2.Id = friend.Followedid;

                //    var user2 = db.Users.Where(i => i.Id == friend.Followedid).SingleOrDefault();
                //    fnd2.Name = user2.FirstName;
                //    fnd2.profileImageId = GetProfileImageId(user2.Photos);
                //    friends.Add(fnd2);
                //}

            }

            return friends;
        }
       public ICollection<UserPhotos> convertToUserPhotos(ICollection<Photos> _Photos)
       {

           List<UserPhotos> photos = new List<UserPhotos>();
          
           foreach (Photos photo in _Photos)
           {
               UserPhotos pto = new UserPhotos();
               pto.Id = photo.Id;
               pto.Name = photo.PhotoName;
               photos.Add(pto);
           }

           return photos;
       }
     
        public ActionResult UserProfile(string Id)
        {
            var user = db.Users
                 .Include(i => i.Contacts)
                 .Include(i => i.Messages)
                 .Include(i => i.WallPosts)
                 .Include(i => i.Photos)
                 .Where(i => i.Id == Id).SingleOrDefault();

            SocialMainModel mainmodel = new SocialMainModel
            {

                _photos = convertToUserPhotos(user.Photos.Cast<Photos>().ToList()),
                _friends = convertToUserFriend(user.Contacts.Cast<Contacts>().ToList()),
                _editProfileViewModel = new EditProfileViewModel 
                {
                    Address=user.Address,
                    City=user.City,
                    DisplayAddress=user.DisplayAddress,
                    DOB=user.DOB,
                    FirstName=user.FirstName,
                    Gender=user.Gender,
                   JobTitle=user.JobTitle,
                   LastName=user.LastName,
                   MiddleName=user.PrefferedName,
                   PhoneNumber=user.PhoneNumber,
                   State=user.State
                }
            };
            return View(mainmodel);
        }

        public ActionResult EditProfile(string Id, string _UName)
        {
            try
            {
                if (Id == null && _UName == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                var user = new ApplicationUser();
                if (Id != null)
                    user = db.Users.Where(i => i.Id == Id).SingleOrDefault();
                else if (_UName != null)
                    user = db.Users.Where(i => i.UserName == _UName).SingleOrDefault();
                EditProfileViewModel userprofiledata = new EditProfileViewModel
                {
                    FirstName = user.FirstName,
                    MiddleName = user.PrefferedName,
                    LastName = user.LastName,
                    Address = user.Address,
                    DisplayAddress = user.DisplayAddress,
                    Gender = user.Gender,
                    State = user.State,
                    JobTitle = user.JobTitle,
                    City = user.City,
                    PhoneNumber = user.PhoneNumber,
                    Id = user.Id,
                    DOB = user.DOB

                };


                if (userprofiledata == null)
                {
                    return HttpNotFound();
                }
                //ViewBag.UserId = new SelectList(db.Users, "Id", "FullName", photo.UserId);
                return View(userprofiledata);
            }
            catch
            {
                return Redirect("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PostWall([Bind(Include = "UserId,PostBody,postImageID")] NewsFeedsViewModel PostData)
        {
            if (ModelState.IsValid)
            {
                var wallpost=new WallPosts
                {
                    PostData=PostData.PostBody,
                    UserId=PostData.UserId,
                    PostDate=DateTime.UtcNow,
                    postimageID=PostData.postImageID
                    
                
                };
                db.WallPosts.Add(wallpost);
                //db.Entry(wallpost).State = EntityState.Modified;
                  db.SaveChanges();
                //return RedirectToAction("Index");

                  NewsFeedsViewModel newsfeed = new NewsFeedsViewModel
                  {
                      wallpostId = wallpost.Id.ToString(),
                      PostBody = wallpost.PostData,
                      postImageID = wallpost.postimageID,
                      PostDate = wallpost.PostDate,
                      profileImageId = GetUserProfileID(wallpost.UserId),
                      UserFullName = db.Users.Where(i => i.Id == wallpost.UserId).SingleOrDefault().FullName,
                      UserId = wallpost.UserId
                  };
                  return PartialView("partial/_singleNewFeed", newsfeed);


                  //return Json(new { SuccessG = "Hogia G Post!" });
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PostComment([Bind(Include = "Comment,UserId,WallPostID")] AddCommentViewModel PostcommentData)
        {
            if (ModelState.IsValid)
            {
                var comment=new SocialComments
                {
                    CommentBody = PostcommentData.Comment,
                   Authorid=PostcommentData.UserId,
                   PostDate=DateTime.UtcNow,
                   WallPostid=Convert.ToInt16(PostcommentData.WallPostID)
                   
                
                };
                db.SocialComments.Add(comment);
                //db.Entry(wallpost).State = EntityState.Modified;
                  db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditProfile([Bind(Include = "Id,FirstName,LastName,MiddleName,Address,PhoneNumber,City,State,Gender,DOB,JobTitle")] EditProfileViewModel userData, string Redirecturl)
        {
            if (ModelState.IsValid)
            {

                var user = db.Users.Where(i => i.Id == userData.Id).SingleOrDefault();
                user.FirstName = userData.FirstName;
                user.PrefferedName = userData.MiddleName;
                user.LastName = userData.LastName;
                user.PhoneNumber = userData.PhoneNumber;
                user.Address = userData.Address;
                user.City = userData.City;
                user.State = userData.State;
                user.Gender = userData.Gender;
                user.DOB = userData.DOB;
                user.JobTitle=userData.JobTitle;
                db.Entry(user).State = EntityState.Modified;
                
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            //ViewBag.UserId = new SelectList(db.Users, "Id", "FullName", photos.UserId);


            return View(userData);
        }

        public ActionResult AllUsers()
        {
            var username=User.Identity.Name;
            var currentUser = db.Users
                .Include(i=>i.Contacts)
                .Where(i => i.UserName == username).SingleOrDefault();
            var users = db.Users
                .Include(i => i.Photos)
                .ToList();
            List<AllPeopleViewModel> usersviewmodel = new List<AllPeopleViewModel>();
            foreach(var user in users)
            {
                AllPeopleViewModel inneruser = new AllPeopleViewModel
                {
                    DisplayAddress=user.DisplayAddress,
                    FullName=user.FullName,
                    Id=user.Id,
                    ProfileImageId = GetProfileImageId(user.Photos),
                    IsFriend=IsUserFriend(currentUser,user)
                    
                };
                if(user.Id!=currentUser.Id)
                usersviewmodel.Add(inneruser);
            }


            return View(usersviewmodel);
        }
        /// <summary>
        /// Check if user is friend or not
        /// </summary>
        /// <param name="currentUser"></param>
        /// <param name="selectedUser"></param>
        /// <returns></returns>
        public bool IsUserFriend(ApplicationUser currentUser, ApplicationUser selectedUser)
        {
            bool isfriend = false;
            foreach(var contacts in currentUser.Contacts)
            {
                if (contacts.Followedid == selectedUser.Id)
                {
                    isfriend = true;
                    break;
                }
            }


            return isfriend;
        }
        /// <summary>
        /// Extract Profile Image
        /// </summary>
        /// <param name="photos"></param>
        /// <returns></returns>
        public string IsProfilePhoto(ICollection<Photos> photos)
        {
            string profilephotoid = string.Empty;
            foreach (var photo in photos)
            {
                if (photo.ProfilePhoto == true)
                {
                    profilephotoid = photo.Id.ToString();
                    break;
                }
            }
            return profilephotoid;
        }
        public ActionResult AddUser(string Id)
        {
            var username = User.Identity.Name;
            var currentUser = db.Users
                .Include(i => i.Contacts)
                .Where(i => i.UserName == username).SingleOrDefault();
            var friend = db.Users
                .Include(i => i.Contacts)
                .Where(i => i.Id == Id).SingleOrDefault();

            var contact_role = db.Contact_Roles.Where(i => i.Role == Role.Friend).SingleOrDefault();
            if(contact_role==null)
            {
                contact_role = new Contact_Roles{
                Role = Role.Friend,
                RoleDescription="Friends"
                };
                db.Entry(contact_role).State = EntityState.Added;
                db.SaveChanges();
            }

            Contacts contact = new Contacts 
            {
                Followed=friend,
                Followedid = friend.Id,
                RoleId=contact_role.Id,
                Followerid=currentUser.Id,
                Follower=currentUser,
                Date_contact_From=DateTime.UtcNow
            };
            currentUser.Contacts.Add(contact);
            db.Entry(currentUser).State = EntityState.Modified;

            db.SaveChanges();

            return RedirectToAction("AllUsers");

        }
        [AllowAnonymous]
        public FileContentResult GetThumbnailImage(int profileImageId)
        {
            Photos photo = db.Photos.FirstOrDefault(p => p.Id == profileImageId);
            if (photo != null)
            {
                return File(photo.Imagethumbnail, photo.ImageMimeType.ToString());
            }
            else
            {
                return null;
            }
        }
        [HttpGet]
        public ActionResult  GetThumbnailImageJson(int profileImageId)
        {
            Photos photo = db.Photos.FirstOrDefault(p => p.Id == profileImageId);
            if (photo != null)
            {
                var jsonresult = Json(new { base64imgage = Convert.ToBase64String(photo.Imagethumbnail) }
                 , JsonRequestBehavior.AllowGet);

                //return File(photo.Imagethumbnail, photo.ImageMimeType.ToString());
                jsonresult.MaxJsonLength = int.MaxValue;
                return jsonresult;
            }
            else
            {
                return null;
            }
        }
        [HttpGet]
        public ActionResult GetOriginalImageJson(int profileImageId)
        {
            Photos photo = db.Photos.FirstOrDefault(p => p.Id == profileImageId);
            if (photo != null)
            {
                var jsonresult= Json(new { base64imgage = Convert.ToBase64String(photo.ImageData) }
                , JsonRequestBehavior.AllowGet);
                jsonresult.MaxJsonLength = int.MaxValue;
                //return File(photo.Imagethumbnail, photo.ImageMimeType.ToString());

                return jsonresult;
            }
            else
            {
                return null;
            }
        }

        [ChildActionOnly]
        public PartialViewResult WeidgetPArtial(string userName)
        {
            var user = db.Users.Where(i => i.UserName == userName).SingleOrDefault();

            string profilephotoid = string.Empty;
            foreach (var photo in user.Photos)
            {
                if (photo.ProfilePhoto == true)
                {
                    profilephotoid = photo.Id.ToString();
                    break;
                }
            }


            widgetViewmodel userpartial = new widgetViewmodel
            {
                UserFuleName = user.FullName,
                UserWork = user.PhoneNumber,
                profileImageId = profilephotoid,
                Id=user.Id

            };

            return PartialView("partial/_widget", userpartial);
        }

        /// <summary>
        /// Select Friends
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [ChildActionOnly]
        public PartialViewResult FriendsPartial(string Id)
        {
            var currentuser = db.Users.Where(i => i.Id == Id).SingleOrDefault();
          
            //string profilephotoid = IsProfilePhoto(currentuser.Photos);
            List<UserFriends> friends = SelectAllFriends(currentuser);
           

            return PartialView("partial/_friends", friends);
        }

        /// <summary>
        /// Select All Friends of current user
        /// </summary>
        /// <param name="currentuser"></param>
        /// <returns></returns>
        public List<UserFriends> SelectAllFriends(ApplicationUser currentuser)
        {
            var allusers = db.Users
                 .Include(i => i.Photos)
                 .ToList();
            List<UserFriends> friends = new List<UserFriends>();
            foreach (var user in allusers)
            {
                if (user.Id != currentuser.Id && IsUserFriend(currentuser, user))
                {
                    UserFriends friend = new UserFriends
                    {
                        Id = user.Id,
                        Name = user.FirstName,
                        profileImageId = GetProfileImageId(user.Photos)
                    };

                    friends.Add(friend);
                }
            }

            return friends;
        }
        [AllowAnonymous]
        public FileContentResult GetOriginalImage(int id)
        {
            Photos photo = db.Photos.FirstOrDefault(p => p.Id == id);
            if (photo != null)
            {
                return File(photo.ImageData, photo.ImageMimeType.ToString());
            }
            else
            {
                return null;
            }
        }


        public ActionResult NewsFeedsPartialJson(string Id)
        {
            var currentuser = db.Users.Where(i => i.Id == Id).SingleOrDefault();
            List<UserFriends> friends = SelectAllFriends(currentuser);
            UserFriends user = new UserFriends
            {
                Id = currentuser.Id,
                Name = currentuser.FirstName,
                profileImageId = GetProfileImageId(currentuser.Photos)
            };

            friends.Add(user);

            string[] friendIds = new string[friends.Count];
            int count = 0;
            foreach (var fnd in friends)
            {
                friendIds[count] = fnd.Id;
                count++;
            }

            // string usersid =String.Join(",",friendIds);//friendIds.ToString();
            var walpost = db.WallPosts
                .OrderByDescending(i => i.PostDate)
                .ToList();
            List<WallPosts> wallposts = new List<WallPosts>();

            foreach (var post in walpost)
            {
                if (friendIds.Contains(post.UserId))
                    wallposts.Add(post);
            }
            // wallposts.OrderByDescending(i => i.PostDate);
            List<NewsFeedsViewModel> newsfeeds = new List<NewsFeedsViewModel>();
            foreach (var wallpost in wallposts)
            {

                NewsFeedsViewModel newsfeed = new NewsFeedsViewModel
                {
                    wallpostId = wallpost.Id.ToString(),
                    PostBody = wallpost.PostData,
                    postImageID = wallpost.postimageID,
                    PostDate = wallpost.PostDate,
                    profileImageId = GetUserProfileID(wallpost.UserId),
                    UserFullName = db.Users.Where(i => i.Id == wallpost.UserId).SingleOrDefault().FullName,
                    UserId = wallpost.UserId
                };
                newsfeeds.Add(newsfeed);
            }

            return PartialView("partial/_newsFeeds", newsfeeds);
        }
        [ChildActionOnly]
        public PartialViewResult NewsFeedsPartial(string Id)
        {
            var currentuser = db.Users.Where(i => i.Id == Id).SingleOrDefault();
            List<UserFriends> friends = SelectAllFriends(currentuser);
            UserFriends user = new UserFriends 
            {
                Id = currentuser.Id,
                Name = currentuser.FirstName,
                profileImageId = GetProfileImageId(currentuser.Photos)
            };

            friends.Add(user);

            string[] friendIds=new string[friends.Count];
            int count=0;
            foreach (var fnd in friends)
            {
                friendIds[count] = fnd.Id;
                count++;
            }

           // string usersid =String.Join(",",friendIds);//friendIds.ToString();
            var walpost = db.WallPosts
                .OrderByDescending(i => i.PostDate)
                .ToList();
            List<WallPosts> wallposts = new List<WallPosts>();

            foreach (var post in walpost)
            {
                if (friendIds.Contains(post.UserId))
                    wallposts.Add(post);
            }
          // wallposts.OrderByDescending(i => i.PostDate);
             List<NewsFeedsViewModel> newsfeeds = new List<NewsFeedsViewModel>();
            foreach (var wallpost in wallposts)
            {

                NewsFeedsViewModel newsfeed = new NewsFeedsViewModel
                {
                    wallpostId=wallpost.Id.ToString(),
                    PostBody = wallpost.PostData,
                    postImageID=wallpost.postimageID,
                    PostDate=wallpost.PostDate,
                    profileImageId = GetUserProfileID(wallpost.UserId),
                    UserFullName = db.Users.Where(i => i.Id == wallpost.UserId).SingleOrDefault().FullName,
                    UserId=wallpost.UserId
                };
                newsfeeds.Add(newsfeed);
            }

            return PartialView("partial/_newsFeeds", newsfeeds);
        }


        [ChildActionOnly]
        public PartialViewResult CommentsPartial(int Id)
        {
            var wallpost = db.WallPosts.Where(i => i.Id == Id).SingleOrDefault();

            List<AddCommentViewModel> comments = new List<AddCommentViewModel>();

            foreach (var cmnt in wallpost.SocialComments)
            {

                AddCommentViewModel comment = new AddCommentViewModel
                {
                    Comment = cmnt.CommentBody,
                    PostedDate =cmnt.PostDate,
                    profileImageId = GetUserProfileID(cmnt.Authorid),
                    UserFullName = db.Users.Where(i => i.Id == cmnt.Authorid).SingleOrDefault().FullName,
                    UserId = cmnt.Authorid,
                    WallPostID = cmnt.WallPostid.ToString()
                };
                comments.Add(comment);
            }
            return PartialView("partial/_comments", comments);
        }

        public PartialViewResult commentFormPartial(string walpostid)
        {


            AddCommentViewModel comments = new AddCommentViewModel 
            {
                WallPostID=walpostid,
                UserId = db.Users.Where(i => i.UserName == User.Identity.Name).SingleOrDefault().Id,
                guid=new Guid()
            };


            return PartialView("partial/_commentFrom", comments);
        }
        public PartialViewResult NewsFeedsFormPartial()
        {
            var UserID = db.Users.Where(i => i.UserName == User.Identity.Name).SingleOrDefault().Id;

            NewsFeedsViewModel comments = new NewsFeedsViewModel 
            {
                UserId = UserID
            };


            return PartialView("partial/_postform", comments);
        }
        public string GetUserProfileID(string userID)
        {
            var user = db.Users
                .Include(i=>i.Photos)
                .Where(i => i.Id == userID).SingleOrDefault();

            return IsProfilePhoto(user.Photos);
        }
    }
}
