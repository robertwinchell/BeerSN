﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Social.Models;
using Social.Authorizations;

namespace Social.Areas.JobAdmin.Controllers
{
    [CustAuthorize]
    public class PublicJobsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: JobAdmin/PublicJobs
        public ActionResult Index()
        {
            var publicJobs = db.PublicJobs.Include(p => p.ApplicationUser).Include(p => p.JobCategory);
            return View(publicJobs.ToList());
        }

        // GET: JobAdmin/PublicJobs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PublicJobs publicJobs = db.PublicJobs.Find(id);
            if (publicJobs == null)
            {
                return HttpNotFound();
            }
            return View(publicJobs);
        }

        // GET: JobAdmin/PublicJobs/Create
        public ActionResult Create()
        {
            ViewBag.AdminId = new SelectList(db.Users, "Id", "FullName");
            ViewBag.JobCategoryId = new SelectList(db.JobCategory, "Id", "JobCatName");
            return View();
        }

        // POST: JobAdmin/PublicJobs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost,ValidateInput(false)]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,JobTitle,JobDetails,JobReq1,JobReq2,JobReq3,JobReq4,JobReq5,JobReq6,JobReq7,JobReq8,JobReq9,JobReq10,JobOppertunity1,JobOppertunity2,JobOppertunity3,JobOppertunity4,JobOppertunity5,JobOppertunity6,JobOppertunity7,JobOppertunity8,JobOppertunity9,JobOppertunity10,ExpirayDate,JobCountry,JobState,JobCity,JobAddressLine1,JobAddressLine2,JobZIPCode,JobCompany,AboutCompany,JobDepartment,JobJoiningDate,AdminId,JobCategoryId")] PublicJobs publicJobs)
        {
            if (ModelState.IsValid)
            {
                publicJobs.PublishDate = DateTime.UtcNow;
                db.PublicJobs.Add(publicJobs);
                db.SaveChanges();
               
                var jobcat = db.JobCategory.Find(publicJobs.JobCategoryId);
                jobcat.LastPostDate = DateTime.UtcNow;

                db.Entry(jobcat).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");

            }

            ViewBag.AdminId = new SelectList(db.Users, "Id", "FullName", publicJobs.AdminId);
            ViewBag.JobCategoryId = new SelectList(db.JobCategory, "Id", "JobCatName", publicJobs.JobCategoryId);
            return View(publicJobs);
        }

        // GET: JobAdmin/PublicJobs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PublicJobs publicJobs = db.PublicJobs.Find(id);
            if (publicJobs == null)
            {
                return HttpNotFound();
            }
            ViewBag.AdminId = new SelectList(db.Users, "Id", "FullName", publicJobs.AdminId);
            ViewBag.JobCategoryId = new SelectList(db.JobCategory, "Id", "JobCatName", publicJobs.JobCategoryId);
            return View(publicJobs);
        }

        // POST: JobAdmin/PublicJobs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
         [HttpPost, ValidateInput(false)]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,JobTitle,JobDetails,JobReq1,JobReq2,ExpirayDate,JobCountry,JobState,JobCity,JobAddressLine1,JobAddressLine2,JobZIPCode,JobCompany,AboutCompany,JobDepartment,JobJoiningDate,AdminId,JobCategoryId")] PublicJobs publicJobs)
        {
            if (ModelState.IsValid)
            {
                var jobs = db.PublicJobs.Find(publicJobs.Id);
                jobs.JobTitle = publicJobs.JobTitle;
                jobs.JobDetails = publicJobs.JobDetails;
                jobs.JobReq1 = publicJobs.JobReq1;
                jobs.JobReq2 = publicJobs.JobReq2;
                jobs.ExpirayDate = publicJobs.ExpirayDate;
                jobs.JobCountry = publicJobs.JobCountry;
                jobs.JobState = publicJobs.JobState;
                jobs.JobCity = publicJobs.JobCity;
                jobs.JobAddressLine1 = publicJobs.JobAddressLine1;
                //AboutCompany,JobDepartment,JobJoiningDate,AdminId,JobCategoryId
                jobs.JobAddressLine2 = publicJobs.JobAddressLine2;
                jobs.JobZIPCode = publicJobs.JobZIPCode;
                jobs.JobCompany = publicJobs.JobCompany;
                jobs.AboutCompany = publicJobs.AboutCompany;
                jobs.JobDepartment = publicJobs.JobDepartment;
                jobs.JobJoiningDate = publicJobs.JobJoiningDate;
                jobs.AdminId = publicJobs.AdminId;
                jobs.JobCategoryId = publicJobs.JobCategoryId;
                db.Entry(jobs).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.AdminId = new SelectList(db.Users, "Id", "FullName", publicJobs.AdminId);
            ViewBag.JobCategoryId = new SelectList(db.JobCategory, "Id", "JobCatName", publicJobs.JobCategoryId);
            return View(publicJobs);
        }

        // GET: JobAdmin/PublicJobs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PublicJobs publicJobs = db.PublicJobs.Find(id);
            if (publicJobs == null)
            {
                return HttpNotFound();
            }
            return View(publicJobs);
        }

        // POST: JobAdmin/PublicJobs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PublicJobs publicJobs = db.PublicJobs.Find(id);
            db.PublicJobs.Remove(publicJobs);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
