﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Social.Models;

namespace Social.Areas.JobAdmin.Controllers
{
    public class JobApplicationsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: JobAdmin/JobApplications
        public ActionResult Index()
        {
            var jobApplications = db.JobApplications.Include(j => j.ApplicationUser).Include(j => j.PublicJobs);
            return View(jobApplications.ToList());
        }

        // GET: JobAdmin/JobApplications/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobApplications jobApplications = db.JobApplications.Find(id);
            if (jobApplications == null)
            {
                return HttpNotFound();
            }
            return View(jobApplications);
        }

        // GET: JobAdmin/JobApplications/Create
        public ActionResult Create()
        {
            ViewBag.UserId = new SelectList(db.Users, "Id", "Address");
            ViewBag.JobId = new SelectList(db.PublicJobs, "Id", "JobTitle");
            return View();
        }

        // POST: JobAdmin/JobApplications/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,ApplicatioDate,Seen,SeenDate,IsSelected,IsShortListed,AttachedResume,contenttype,ResumeTitle,PastedResume,JobId,UserId")] JobApplications jobApplications)
        {
            if (ModelState.IsValid)
            {
                db.JobApplications.Add(jobApplications);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.UserId = new SelectList(db.Users, "Id", "Address", jobApplications.UserId);
            ViewBag.JobId = new SelectList(db.PublicJobs, "Id", "JobTitle", jobApplications.JobId);
            return View(jobApplications);
        }

        // GET: JobAdmin/JobApplications/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobApplications jobApplications = db.JobApplications.Find(id);
            if (jobApplications == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserId = new SelectList(db.Users, "Id", "Address", jobApplications.UserId);
            ViewBag.JobId = new SelectList(db.PublicJobs, "Id", "JobTitle", jobApplications.JobId);
            return View(jobApplications);
        }

        // POST: JobAdmin/JobApplications/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,ApplicatioDate,Seen,SeenDate,IsSelected,IsShortListed,AttachedResume,contenttype,ResumeTitle,PastedResume,JobId,UserId")] JobApplications jobApplications)
        {
            if (ModelState.IsValid)
            {
                db.Entry(jobApplications).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.UserId = new SelectList(db.Users, "Id", "Address", jobApplications.UserId);
            ViewBag.JobId = new SelectList(db.PublicJobs, "Id", "JobTitle", jobApplications.JobId);
            return View(jobApplications);
        }

        // GET: JobAdmin/JobApplications/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            JobApplications jobApplications = db.JobApplications.Find(id);
            if (jobApplications == null)
            {
                return HttpNotFound();
            }
            return View(jobApplications);
        }

        // POST: JobAdmin/JobApplications/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            JobApplications jobApplications = db.JobApplications.Find(id);
            db.JobApplications.Remove(jobApplications);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
