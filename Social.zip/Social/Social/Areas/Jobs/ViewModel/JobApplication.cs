﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Social.Areas.Jobs.ViewModel
{
    public class JobApplication
    {
       

        public int JobId { get; set; }

        [DisplayName("Upload Resume")]
        public HttpPostedFileBase attachResume { get; set; }
        [DisplayName("Resume Title")]
        public string ResumeTitle { get; set; }
        [DisplayName("Paste Resume")]
        public string PastedResume { get; set; }
       
        //[ForeignKey("JobId")]
        //public virtual PublicJobs PublicJobs { get; set; }

        //public string UserId { get; set; }
        //[ForeignKey("UserId")]
        //public virtual ApplicationUser ApplicationUser { get; set; }
    }
}