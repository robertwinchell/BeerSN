﻿using Social.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.Areas.Jobs.ViewModel
{
    public class CatIndexData
    {
        public IEnumerable<PublicJobs> PublicJobs { get; set; }
        public IEnumerable<JobCategory> JobCategory { get; set; } 
    }
}