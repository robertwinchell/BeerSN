﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Social.Areas.JobAdmin.Models;
using Social.Models;
using Social.Areas.Jobs.ViewModel;
using Microsoft.AspNet.Identity;
using System.IO;
namespace Social.Areas.Jobs.Controllers
{
    public class PublicJobsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Jobs/PublicJobs
        public ActionResult Index()
        {
            //var viewModel = new CatIndexData();
            //viewModel.JobCategory = db.JobCategory
            //    .Include(i => i.PublicJobs.Select(x => x.JobTitle));
            var JobCat = db.JobCategory.Include(i=>i.PublicJobs);


            //var publicJobs = db.PublicJobs.Include(p => p.ApplicationUser).Include(p => p.JobCategory);
            return View(JobCat.ToList());
        }
        [Authorize]
        public ActionResult Apply(int id)
        {
            JobApplication application = new JobApplication { JobId = id };

            return View(application);
        }
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Apply(JobApplication application)
        {
            //HttpPostedFileBase file = Request.Files[0];
            //byte[] imageSize = new byte[file.ContentLength];
            //file.InputStream.Read(imageSize, 0, (int)file.ContentLength);
            //Image image = new Image()
            //{
            //    Name = file.FileName.Split('\\').Last(),
            //    Size = file.ContentLength,
            //    Title = fileTitle,
            //    ID = 1,
            //    Image1 = imageSize
            //};
            //db.Images.AddObject(image);
            //db.SaveChanges();
            //return RedirectToAction("Detail");


            //application.PastedResume

            HttpPostedFileBase file = application.attachResume;
            byte[] resumefile=null;
            if (file.ContentLength > 0)
            {
                resumefile = new byte[file.ContentLength];
                file.InputStream.Read(resumefile, 0, (int)file.ContentLength);
            }
            JobApplications app = new JobApplications 
            {
                JobId=application.JobId,
                PastedResume=application.PastedResume?? "",
                ResumeTitle=application.ResumeTitle,
                ApplicatioDate=DateTime.UtcNow,
                contenttype=application.attachResume.ContentType,
                UserId= User.Identity.GetUserId(),
                AttachedResume = resumefile ?? null,
                SeenDate = DateTime.UtcNow,
                IsSelected=false,
                IsShortListed=false,
                Seen=false
            };
            db.JobApplications.Add(app);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

       



        // GET: Jobs/PublicJobs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PublicJobs publicJobs = db.PublicJobs.Find(id);
            if (publicJobs == null)
            {
                return HttpNotFound();
            }
            return View(publicJobs);
        }

        // GET: Jobs/PublicJobs/Create
        public ActionResult Create()
        {
            ViewBag.AdminId = new SelectList(db.Users, "Id", "FullName");
            ViewBag.JobCategoryId = new SelectList(db.JobCategory, "Id", "JobCatName");
            return View();
        }

        // POST: Jobs/PublicJobs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,JobTitle,JobDetails,JobReq1,JobReq2,JobReq3,JobReq4,JobReq5,JobReq6,JobReq7,JobReq8,JobReq9,JobReq10,JobOppertunity1,JobOppertunity2,JobOppertunity3,JobOppertunity4,JobOppertunity5,JobOppertunity6,JobOppertunity7,JobOppertunity8,JobOppertunity9,JobOppertunity10,PublishDate,ExpirayDate,JobCountry,JobState,JobCity,JobAddressLine1,JobAddressLine2,JobZIPCode,JobCompany,AboutCompany,JobDepartment,JobJoiningDate,AdminId,JobCategoryId")] PublicJobs publicJobs)
        {
            if (ModelState.IsValid)
            {
                db.PublicJobs.Add(publicJobs);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.AdminId = new SelectList(db.Users, "Id", "FullName", publicJobs.AdminId);
            ViewBag.JobCategoryId = new SelectList(db.JobCategory, "Id", "JobCatName", publicJobs.JobCategoryId);
            return View(publicJobs);
        }

        // GET: Jobs/PublicJobs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PublicJobs publicJobs = db.PublicJobs.Find(id);
            if (publicJobs == null)
            {
                return HttpNotFound();
            }
            ViewBag.AdminId = new SelectList(db.Users, "Id", "FullName", publicJobs.AdminId);
            ViewBag.JobCategoryId = new SelectList(db.JobCategory, "Id", "JobCatName", publicJobs.JobCategoryId);
            return View(publicJobs);
        }

        // POST: Jobs/PublicJobs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,JobTitle,JobDetails,JobReq1,JobReq2,JobReq3,JobReq4,JobReq5,JobReq6,JobReq7,JobReq8,JobReq9,JobReq10,JobOppertunity1,JobOppertunity2,JobOppertunity3,JobOppertunity4,JobOppertunity5,JobOppertunity6,JobOppertunity7,JobOppertunity8,JobOppertunity9,JobOppertunity10,PublishDate,ExpirayDate,JobCountry,JobState,JobCity,JobAddressLine1,JobAddressLine2,JobZIPCode,JobCompany,AboutCompany,JobDepartment,JobJoiningDate,AdminId,JobCategoryId")] PublicJobs publicJobs)
        {
            if (ModelState.IsValid)
            {
                db.Entry(publicJobs).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.AdminId = new SelectList(db.Users, "Id", "FullName", publicJobs.AdminId);
            ViewBag.JobCategoryId = new SelectList(db.JobCategory, "Id", "JobCatName", publicJobs.JobCategoryId);
            return View(publicJobs);
        }

        // GET: Jobs/PublicJobs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PublicJobs publicJobs = db.PublicJobs.Find(id);
            if (publicJobs == null)
            {
                return HttpNotFound();
            }
            return View(publicJobs);
        }

        // POST: Jobs/PublicJobs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PublicJobs publicJobs = db.PublicJobs.Find(id);
            db.PublicJobs.Remove(publicJobs);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
