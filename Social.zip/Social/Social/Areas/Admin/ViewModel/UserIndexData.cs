﻿using IdentitySample.Models;
using Social.Areas.JobAdmin.Models;
using Social.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.Areas.Admin.ViewModel
{
    public class UserIndexData
    {
        public IEnumerable<ApplicationUser> Users { get; set; }
        public IEnumerable<Messages> MessagesReceived { get; set; } 
        public IEnumerable<Messages> MessagesSent { get; set; }
        public IEnumerable<Contacts> Contacts { get; set; }
        public IEnumerable<Photos> Photos { get; set; }
        public IEnumerable<JobApplications> JobApplications { get; set; }
        public IEnumerable<PublicJobs> PublicJobs { get; set; }
    }
}