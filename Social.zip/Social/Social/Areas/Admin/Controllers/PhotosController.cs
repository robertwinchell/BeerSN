﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Social.Models;
using Social.ViewModel;
using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing;
using System.Drawing.Imaging;
using Social.Authorizations;

namespace Social.Areas.Admin.Controllers
{
    //[CustAuthorize]
    
    public class PhotosController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Admin/Photos
        public ActionResult Index()
        {
            var photos = db.Photos.Include(p => p.ApplicationUser);
            return View(photos.ToList());
        }

        // GET: Admin/Photos/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Photos photos = db.Photos.Find(id);
            if (photos == null)
            {
                return HttpNotFound();
            }
            return View(photos);
        }

        // GET: Admin/Photos/Create
        public ActionResult Create()
        {
            ViewBag.UserId = new SelectList(db.Users, "Id", "FullName" );
            return View();
        }

        private byte[] processImage(HttpPostedFileBase photo, ref byte[] imageData, string userid)
        {
            var filename = Path.GetFileName(photo.FileName);
            System.Drawing.Image savedFileName =
            System.Drawing.Image.FromStream(photo.InputStream);

            System.Drawing.Image savedFileName1 =
            System.Drawing.Image.FromStream(photo.InputStream);



            imageData = new byte[photo.ContentLength];
            //photo.InputStream.Read(imageData, 0, photo.ContentLength);

            using (var srcImage1 = savedFileName)
            using (var newImage = new Bitmap(savedFileName.Width, savedFileName.Height))
            using (var graphics = Graphics.FromImage(newImage))
            using (var stream1 = new MemoryStream())
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                graphics.DrawImage(srcImage1, new Rectangle(0, 0, savedFileName.Width, savedFileName.Height));
                newImage.Save(stream1, ImageFormat.Png);
                var thumbNew = File(stream1.ToArray(), "image/png");
                imageData= thumbNew.FileContents;
            }



            //photo.SaveAs(savedFileName);




            //Save image to file
            //var filename = "MyDefaultImage." + Path.GetExtension(photo.FileName);
            //string Userpath = userid;
            //string filePathOriginalvirtuel = "/Content/" + Userpath + "/Uploads/Originals";
            //var filePathOriginal = Server.MapPath(filePathOriginalvirtuel);
            //string filePathThumbnailVirtual = "/Content/" + Userpath + "/Uploads/Thumbnails";
            //var filePathThumbnail = Server.MapPath(filePathThumbnailVirtual);
            //if (!Directory.Exists(filePathOriginal))
            //    Directory.CreateDirectory(filePathOriginal);
            //if (!Directory.Exists(filePathThumbnail))
            //    Directory.CreateDirectory(filePathThumbnail);
            //string savedFileName = Path.Combine(filePathOriginal, filename);
            //photo.SaveAs(savedFileName);

            //Read image back from file and create thumbnail from it
            // var imageFile = Path.Combine(Server.MapPath(filePathOriginalvirtuel), filename);
            using (var srcImage = savedFileName1)
            using (var newImage = new Bitmap(100, 100))
            using (var graphics = Graphics.FromImage(newImage))
            using (var stream = new MemoryStream())
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                graphics.DrawImage(srcImage, new Rectangle(0, 0, 100, 100));
                newImage.Save(stream, ImageFormat.Png);
                var thumbNew = File(stream.ToArray(), "image/png");
                return thumbNew.FileContents;
            }


        }
        // POST: Admin/Photos/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PhotoTitle,PhotoName,ImageData,ProfilePhoto,UserId")] PhotoViewModel photos)
        {
            if (ModelState.IsValid)
            {
                byte[] imageData=null ;
                byte[] Imagethumbnail=processImage(photos.ImageData,ref imageData,photos.UserId);
              

                var photo = new Photos
                {
                    PhotoName = photos.ImageData.FileName,
                    PhotoTitle = photos.PhotoTitle,
                    ImageMimeType = photos.ImageData.ContentLength,
                    ImageData = imageData,
                    ProfilePhoto = photos.ProfilePhoto,
                    UserId = photos.UserId,
                    AddedDate=DateTime.UtcNow

                };
                photo.Imagethumbnail = Imagethumbnail;
               



               
                db.Photos.Add(photo);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.UserId = new SelectList(db.Users, "Id", "FullName", photos.UserId);
            return View(photos);
        }
        [AllowAnonymous]
        public FileContentResult GetThumbnailImage(int id)
        {
            Photos photo = db.Photos.FirstOrDefault(p => p.Id == id);
            if (photo != null)
            {
                return File(photo.Imagethumbnail, photo.ImageMimeType.ToString());
            }
            else
            {
                return null;
            }
        }

       
    
        public FileContentResult GetOriginalImage(int id)
        {
            Photos photo = db.Photos.FirstOrDefault(p => p.Id == id);
            if (photo != null)
            {
                return File(photo.ImageData, photo.ImageMimeType.ToString());
            }
            else
            {
                return null;
            }
        }

        // GET: Admin/Photos/Edit/5
        public ActionResult Edit(int? id)
        {

          


            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Photos photo = db.Photos.Find(id);


            PhotoViewModel photos = new PhotoViewModel
            {
                Id=photo.Id,
                PhotoTitle = photo.PhotoTitle,
                ProfilePhoto = photo.ProfilePhoto,
                UserId = photo.UserId,
                AddedDate=photo.AddedDate
            };

            if (photos == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserId = new SelectList(db.Users, "Id", "FullName", photo.UserId);
            return View(photos);
        }

        // POST: Admin/Photos/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,PhotoTitle,PhotoName,ImageData,ProfilePhoto,UserId,AddedDate")] PhotoViewModel photos, string Redirecturl)
        {
            if (ModelState.IsValid)
            {

                byte[] imageData = null;
                byte[] Imagethumbnail = processImage(photos.ImageData, ref imageData, photos.UserId);

                var photo = db.Photos.Find(photos.Id);
                photo.PhotoName = photos.ImageData.FileName;
                photo.PhotoTitle = photos.PhotoTitle;
                photo.ImageMimeType = photos.ImageData.ContentLength;
                photo.ImageData = imageData;
                photo.ProfilePhoto = photos.ProfilePhoto;
                photo.UserId = photos.UserId;

                photo.Imagethumbnail = Imagethumbnail;

                db.Entry(photo).State = EntityState.Modified;
                db.SaveChanges();

                if (Redirecturl != null)
                    return Redirect(Redirecturl);

                return RedirectToAction("Index");
            }
            ViewBag.UserId = new SelectList(db.Users, "Id", "FullName", photos.UserId);

           
            return View(photos);
        }

        // GET: Admin/Photos/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Photos photos = db.Photos.Find(id);
            if (photos == null)
            {
                return HttpNotFound();
            }
            return View(photos);
        }

        // POST: Admin/Photos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Photos photos = db.Photos.Find(id);
            db.Photos.Remove(photos);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
