﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Social.Models;
using Social.Authorizations;

namespace Social.Areas.Admin.Controllers
{
    [CustAuthorize]
    public class Contact_RolesController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Admin/Contact_Roles
        public ActionResult Index()
        {
            return View(db.Contact_Roles.ToList());
        }

        // GET: Admin/Contact_Roles/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contact_Roles contact_Roles = db.Contact_Roles.Find(id);
            if (contact_Roles == null)
            {
                return HttpNotFound();
            }
            return View(contact_Roles);
        }

        // GET: Admin/Contact_Roles/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Admin/Contact_Roles/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,RoleDescription,Role")] Contact_Roles contact_Roles)
        {
            if (ModelState.IsValid)
            {
                db.Contact_Roles.Add(contact_Roles);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(contact_Roles);
        }

        // GET: Admin/Contact_Roles/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contact_Roles contact_Roles = db.Contact_Roles.Find(id);
            if (contact_Roles == null)
            {
                return HttpNotFound();
            }
            return View(contact_Roles);
        }

        // POST: Admin/Contact_Roles/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,RoleDescription,Role")] Contact_Roles contact_Roles)
        {
            if (ModelState.IsValid)
            {
                db.Entry(contact_Roles).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(contact_Roles);
        }

        // GET: Admin/Contact_Roles/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Contact_Roles contact_Roles = db.Contact_Roles.Find(id);
            if (contact_Roles == null)
            {
                return HttpNotFound();
            }
            return View(contact_Roles);
        }

        // POST: Admin/Contact_Roles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Contact_Roles contact_Roles = db.Contact_Roles.Find(id);
            db.Contact_Roles.Remove(contact_Roles);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
