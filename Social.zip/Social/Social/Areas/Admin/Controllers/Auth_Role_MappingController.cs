﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using IdentitySample.Models;
using Social.Models;
using Social.Authorizations;

namespace Social.Areas.Admin.Controllers
{
    [CustAuthorize]
    public class Auth_Role_MappingController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Admin/Auth_Role_Mapping
        public ActionResult Index()
        {
            var auth_Role_Mapping = db.Auth_Role_Mapping
                .Include(a => a.AuthAction)
                .Include(a => a.AuthArea)
                .Include(a => a.AuthController)
                .Include(a => a.SocialRole)
                .OrderBy(i => i.SocialRole.Name)
                .ThenBy(i => i.AuthController.ControllerName)
                .ThenBy(i => i.AuthArea.AreaName)
                .ThenBy(i => i.AuthAction.ActionName);
               

                //.OrderBy(i=>i.AuthController.ControllerName)
                //.OrderBy(i => i.AuthArea.AreaName)
                //.OrderBy(i => i.AuthAction.ActionName);
            return View(auth_Role_Mapping.ToList());
        }

        // GET: Admin/Auth_Role_Mapping/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Auth_Role_Mapping auth_Role_Mapping = db.Auth_Role_Mapping.Find(id);
            if (auth_Role_Mapping == null)
            {
                return HttpNotFound();
            }
            return View(auth_Role_Mapping);
        }

        // GET: Admin/Auth_Role_Mapping/Create
        public ActionResult Create()
        {
            ViewBag.AuthActionId = new SelectList(db.AuthAction, "Id", "ActionName");
            ViewBag.AuthAreaId = new SelectList(db.AuthArea, "Id", "AreaName");
            ViewBag.AuthControllerId = new SelectList(db.AuthController, "Id", "ControllerName");
            ViewBag.SocialRoleId = new SelectList(db.Roles, "Id", "Name");
            return View();
        }

        // POST: Admin/Auth_Role_Mapping/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,AuthAreaId,AuthControllerId,AuthActionId,SocialRoleId")] Auth_Role_Mapping auth_Role_Mapping)
        {
           if (ModelState.IsValid )
            {
                db.Auth_Role_Mapping.Add(auth_Role_Mapping);
                //db.Auth_Role_Mapping.Contains(auth_Role_Mapping);
                
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.AuthActionId = new SelectList(db.AuthAction, "Id", "ActionName", auth_Role_Mapping.AuthActionId);
            ViewBag.AuthAreaId = new SelectList(db.AuthArea, "Id", "AreaName", auth_Role_Mapping.AuthAreaId);
            ViewBag.AuthControllerId = new SelectList(db.AuthController, "Id", "ControllerName", auth_Role_Mapping.AuthControllerId);
            ViewBag.SocialRoleId = new SelectList(db.Roles, "Id", "Name", auth_Role_Mapping.SocialRoleId);
            return View(auth_Role_Mapping);
        }

        // GET: Admin/Auth_Role_Mapping/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Auth_Role_Mapping auth_Role_Mapping = db.Auth_Role_Mapping.Find(id);
            if (auth_Role_Mapping == null)
            {
                return HttpNotFound();
            }
            ViewBag.AuthActionId = new SelectList(db.AuthAction, "Id", "ActionName", auth_Role_Mapping.AuthActionId);
            ViewBag.AuthAreaId = new SelectList(db.AuthArea, "Id", "AreaName", auth_Role_Mapping.AuthAreaId);
            ViewBag.AuthControllerId = new SelectList(db.AuthController, "Id", "ControllerName", auth_Role_Mapping.AuthControllerId);
            ViewBag.SocialRoleId = new SelectList(db.Roles, "Id", "Name", auth_Role_Mapping.SocialRoleId);
            return View(auth_Role_Mapping);
        }

        // POST: Admin/Auth_Role_Mapping/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,AuthAreaId,AuthControllerId,AuthActionId,SocialRoleId")] Auth_Role_Mapping auth_Role_Mapping)
        {
            if (ModelState.IsValid)
            {
                db.Entry(auth_Role_Mapping).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.AuthActionId = new SelectList(db.AuthAction, "Id", "ActionName", auth_Role_Mapping.AuthActionId);
            ViewBag.AuthAreaId = new SelectList(db.AuthArea, "Id", "AreaName", auth_Role_Mapping.AuthAreaId);
            ViewBag.AuthControllerId = new SelectList(db.AuthController, "Id", "ControllerName", auth_Role_Mapping.AuthControllerId);
            ViewBag.SocialRoleId = new SelectList(db.Roles, "Id", "Name", auth_Role_Mapping.SocialRoleId);
            return View(auth_Role_Mapping);
        }

        // GET: Admin/Auth_Role_Mapping/Delete/5
        public ActionResult Delete(int? id)
        {
            
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Auth_Role_Mapping auth_Role_Mapping = db.Auth_Role_Mapping.Find(id);
            if (auth_Role_Mapping == null)
            {
                return HttpNotFound();
            }
            return View(auth_Role_Mapping);
        }

        // POST: Admin/Auth_Role_Mapping/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Auth_Role_Mapping auth_Role_Mapping = db.Auth_Role_Mapping.Find(id);
            db.Auth_Role_Mapping.Remove(auth_Role_Mapping);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
