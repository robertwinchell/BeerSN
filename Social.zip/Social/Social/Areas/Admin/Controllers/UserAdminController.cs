﻿using IdentitySample.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Social.Areas.Admin.ViewModel;
using System.Net.Mail;
using Social.Authorizations;

namespace Social.Areas.Admin.Controllers
{
  
    [CustAuthorize]
    public class UsersAdminController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        public UsersAdminController()
        {
        }

        public UsersAdminController(ApplicationUserManager userManager, ApplicationRoleManager roleManager)
        {
            UserManager = userManager;
            RoleManager = roleManager;
        }

        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        private ApplicationRoleManager _roleManager;
        public ApplicationRoleManager RoleManager
        {
            get
            {
                return _roleManager ?? HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
            }
            private set
            {
                _roleManager = value;
            }
        }

        //
        // GET: /Users/
        public ActionResult Index(Guid? id)
        {
            var viewModel = new UserIndexData();
            viewModel.Users = db.Users
                .Include(i => i.Contacts.Select(y=>y.Contact_Roles))
                .Include(i => i.Photos)
                .Include(i => i.Messages.Select(c => c.To))
                .OrderBy(i => i.FirstName);
            if (id != null)
            {
                string strid = id.ToString();
                ViewBag.UserID = id.Value.ToString();
                viewModel.Contacts = db.Contacts.Where(
                    i => i.Followerid == strid).Include(c=>c.Contact_Roles).ToList();
            }
            if (id != null)
            {
                string strid = id.ToString();
                ViewBag.UserID = id.Value.ToString();
                viewModel.MessagesSent = db.Messages.Where(
                    i => i.FromId == strid).ToList();
            }
            if (id != null)
            {
                string strid = id.ToString();
                ViewBag.UserID = id.Value.ToString();
                viewModel.MessagesReceived = db.Messages.Where(
                    i => i.ToId == strid).ToList();
            }
            if (id != null)
            {
                string strid = id.ToString();
                ViewBag.UserID = id.Value.ToString();
                viewModel.Photos = db.Photos.Where(
                    i => i.UserId == strid).ToList();
            }
            if (id != null)
            {
                string strid = id.ToString();
                ViewBag.UserID = id.Value.ToString();
                viewModel.JobApplications = db.JobApplications.Where(
                    i => i.UserId == strid).ToList();
            }
            if (id != null)
            {
                string strid = id.ToString();
                ViewBag.UserID = id.Value.ToString();
                viewModel.PublicJobs = db.PublicJobs.Where(
                    i => i.AdminId == strid).ToList();
            }

            if (id != null)
            {
                string strid = id.ToString();
                ViewBag.UserID = id.Value.ToString();
                viewModel.Photos = db.Photos.Where(
                    i => i.UserId == strid).ToList();
            }
            //if (ContactId != null)
            //{
            //    ViewBag.ContactId = ContactId.Value;
            //    viewModel.Users = viewModel.Contacts.Where(
            //        x => x.Id == ContactId).Single().Department;
            //}

            return View(viewModel);
        }

        //
        // GET: /Users/Details/5
        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);
            
            ViewBag.RoleNames = await UserManager.GetRolesAsync(user.Id);
           // var result = await UserManager.AddToRolesAsync(user.Id, selectedRoles);
            
            return View(user);
        }

        //
        // GET: /Users/Create
        public async Task<ActionResult> Create()
        {
            //Get the list of Roles
            ViewBag.RoleId = new SelectList(await RoleManager.Roles.ToListAsync(), "Name", "Name");
            return View();
        }

        //
        // POST: /Users/Create
        [HttpPost]
        public async Task<ActionResult> Create(UserViewModel userViewModel, params string[] selectedRoles)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser {
                    UserName = new MailAddress(userViewModel.Email).User,
                    Email = userViewModel.Email,
                    PrefferedName=userViewModel.PreferedName,
                    LastName=userViewModel.LastName,
                    FirstName=userViewModel.FirstName,
                    IsActive=false
                };
                var adminresult = await UserManager.CreateAsync(user, userViewModel.Password);

                //Add User to the selected Roles 
                if (adminresult.Succeeded)
                {
                    var code = await UserManager.GenerateEmailConfirmationTokenAsync(user.Id);
                    var host = System.Web.HttpContext.Current.Request.Url;
                    var callbackUrl = Url.Action("ConfirmEmail", "Account", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);
                    await UserManager.SendEmailAsync(user.Id, "Confirm your account", "Please confirm your account by clicking this link: <a href=\"" + callbackUrl + "\">link</a> <br/> Your Password is: " + userViewModel.Password);


                    if (selectedRoles != null)
                    {
                        var result = await UserManager.AddToRolesAsync(user.Id, selectedRoles);
                        if (!result.Succeeded)
                        {
                            ModelState.AddModelError("", result.Errors.First());
                            ViewBag.RoleId = new SelectList(await RoleManager.Roles.ToListAsync(), "Name", "Name");
                            return View();
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", adminresult.Errors.First());
                    ViewBag.RoleId = new SelectList(RoleManager.Roles, "Name", "Name");
                    return View();

                }
                return RedirectToAction("Index");
            }
            ViewBag.RoleId = new SelectList(RoleManager.Roles, "Name", "Name");
            return View();
        }

        //
        // GET: /Users/Edit/1
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);
            if (user == null)
            {
                return HttpNotFound();
            }

            var userRoles = await UserManager.GetRolesAsync(user.Id);

            return View(new EditUserViewModel()
            {
                Id = user.Id,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                IsActive = user.IsActive,
                RolesList = RoleManager.Roles.ToList().Select(x => new SelectListItem()
                {
                    Selected = userRoles.Contains(x.Name),
                    Text = x.Name,
                    Value = x.Name
                })
            });
        }

        //
        // POST: /Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Email,Id,FirstName,LastName,IsActive")] EditUserViewModel editUser, params string[] selectedRole)
        {
            if (ModelState.IsValid)
            {
                var user = await UserManager.FindByIdAsync(editUser.Id);
                if (user == null)
                {
                    return HttpNotFound();
                }

                user.UserName = editUser.Email;
                user.Email = editUser.Email;
                user.FirstName = editUser.FirstName;
                user.LastName = editUser.LastName;
                user.IsActive = editUser.IsActive;
                user.PrefferedName = editUser.PreferedName;
                var userRoles = await UserManager.GetRolesAsync(user.Id);

                selectedRole = selectedRole ?? new string[] { };

                var result = await UserManager.AddToRolesAsync(user.Id, selectedRole.Except(userRoles).ToArray<string>());

                if (!result.Succeeded)
                {
                    ModelState.AddModelError("", result.Errors.First());
                    return View();
                }
                result = await UserManager.RemoveFromRolesAsync(user.Id, userRoles.Except(selectedRole).ToArray<string>());

                if (!result.Succeeded)
                {
                    ModelState.AddModelError("", result.Errors.First());
                    return View();
                }
                return RedirectToAction("Index");
            }
            ModelState.AddModelError("", "Something failed.");
            return View();
        }

        //
        // GET: /Users/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        //
        // POST: /Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            if (ModelState.IsValid)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                var user = await UserManager.FindByIdAsync(id);
                if (user == null)
                {
                    return HttpNotFound();
                }
                var result = await UserManager.DeleteAsync(user);
                if (!result.Succeeded)
                {
                    ModelState.AddModelError("", result.Errors.First());
                    return View();
                }
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}
