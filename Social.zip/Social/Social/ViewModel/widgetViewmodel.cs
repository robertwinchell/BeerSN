﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.ViewModel
{
    public class widgetViewmodel
    {
        public string Id { get; set; }
        public string UserFuleName { get; set; }
        public string UserWork { get; set; }
        public string profileImageId { get; set; }
        //public HttpPostedFileBase thumbnail { get; set; }

    }
}