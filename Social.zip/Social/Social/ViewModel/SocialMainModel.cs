﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.ViewModel
{
    public class SocialMainModel
    {
       
        public widgetViewmodel _widgetViewmodel { get; set; }
        public ICollection<UserPhotos> _photos { get; set; }
        public ICollection<UserFriends> _friends { get; set; }
        public ICollection<NewsFeedsViewModel> _newsFeedsViewModel { get; set; }
        public EditProfileViewModel _editProfileViewModel { get; set; }

    }
}