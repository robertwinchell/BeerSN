﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.ViewModel
{
    public class UserFriends
    {
        public UserFriends() { }
        public string Id { get; set; }
        public string Name { get; set; }
        public string profileImageId { get; set; }
    }
}