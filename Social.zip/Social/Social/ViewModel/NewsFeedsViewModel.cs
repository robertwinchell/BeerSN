﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.ViewModel
{
    public class NewsFeedsViewModel
    {
        public NewsFeedsViewModel() { }
        public string wallpostId { get; set; }
        public string UserId { get; set; }
        public string profileImageId { get; set; }
        public string UserFullName { get; set; }
        public DateTime PostDate { get; set; }
        public string postImageID { get; set; }
        public string PostBody { get; set; }

        //public ICollection<AddCommentViewModel> comments { get; set; }
        //public ICollection<AddCommentViewModel> newcommentsViweModel { get; set; }
    }
}