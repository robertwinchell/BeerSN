﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Web;

namespace Social.ViewModel
{
    public class PhotoViewModel
    {
        public int Id { get; set; }
        [Required]
        public string PhotoTitle { get; set; }

        [Required]
        public HttpPostedFileBase ImageData { get; set; }

        public bool ProfilePhoto { get; set; }
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime AddedDate { get; set; }
        public string UserId { get; set; }

        

    }
}