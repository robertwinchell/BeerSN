﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.ViewModel
{
    public class AllPeopleViewModel
    {
        public string Id { get; set; }
        public string FullName { get; set; }
        public string ProfileImageId { get; set; }
        public string DisplayAddress { get; set; }
        public bool IsFriend { get; set; }
    }
}