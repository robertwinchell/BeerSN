﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Social.ViewModel
{
    public class AddCommentViewModel
    {

        public AddCommentViewModel() { }
        public string UserId { get; set; }
        public string profileImageId { get; set; }
        public string UserFullName { get; set; }
        public DateTime PostedDate { get; set; }
        [Required]
        public string Comment { get; set; }
        public string WallPostID { get; set; }
        public Guid guid { get; set; }
    }
}