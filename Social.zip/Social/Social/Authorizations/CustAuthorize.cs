﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Mvc;
using System.Web.Security;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;


using Microsoft.AspNet.Identity.EntityFramework;

using System.Net;
using System.Threading.Tasks;
using Social.Models;

namespace Social.Authorizations
{
    public class CustAuthorize : AuthorizeAttribute
    {


        public string _controller { get; set; }
        public string _action { get; set; }
        public string _area { get; set; }
        private ApplicationDbContext db = new ApplicationDbContext();

        protected ApplicationDbContext ApplicationDbContext { get; set; }
        protected UserManager<ApplicationUser> UserManager { get; set; }
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            base.OnAuthorization(filterContext);
        }
        public async Task<bool> IsAuthorizeSocial(string Area, string controller, string Action, string username)
        {
            this.ApplicationDbContext = new ApplicationDbContext();
            this.UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(this.ApplicationDbContext));
            var user = UserManager.FindByName(username);
            var roles = await UserManager.GetRolesAsync(user.Id).ConfigureAwait(continueOnCapturedContext: false);

            string last = roles.Last();
            int counter = 3;
            string partialSting = string.Empty;
            List<object> parameters = new List<object>();
            parameters.Add(controller);
            parameters.Add(Action);
            parameters.Add(Area);
            foreach (string str in roles)
            {
                if (str.Contains(last))
                {
                    partialSting += "@p" + counter.ToString() + ")))";
                    parameters.Add(str);
                }
                else
                {
                    partialSting += "@p" + counter.ToString() + ",";
                    parameters.Add(str);
                }

                counter++;
            }

            var query = @"SELECT 
                        [Extent1].[Id] AS [Id], 
                        [Extent1].[AuthAreaId] AS [AuthAreaId], 
                        [Extent1].[AuthControllerId] AS [AuthControllerId], 
                        [Extent1].[AuthActionId] AS [AuthActionId], 
                        [Extent1].[SocialRoleId] AS [SocialRoleId]
                        FROM      [dbo].[Auth_Role_Mapping] AS [Extent1]
                        INNER JOIN [dbo].[AuthControllers] AS [Extent2] ON [Extent1].[AuthControllerId] = [Extent2].[Id]
                        INNER JOIN [dbo].[AuthActions] AS [Extent3] ON [Extent1].[AuthActionId] = [Extent3].[Id]
                        INNER JOIN [dbo].[AuthAreas] AS [Extent4] ON [Extent1].[AuthAreaId] = [Extent4].[Id]
                        LEFT OUTER JOIN [dbo].[AspNetRoles] AS [Extent5] ON ([Extent1].[SocialRoleId] = [Extent5].[Id]) 
                        AND ([Extent5].[Discriminator] = N'SocialRole')
                        LEFT OUTER JOIN [dbo].[AspNetRoles] AS [Extent6] ON ([Extent1].[SocialRoleId] = [Extent6].[Id]) 
                        AND ([Extent6].[Discriminator] = N'SocialRole')
                        WHERE ([Extent2].[ControllerName] =  @p0)
	                    AND ([Extent3].[ActionName] =  @p1)
                        AND ([Extent4].[AreaName] =  @p2)
                        AND (([Extent5].[Name] in(  " + partialSting;
            object[] param = parameters.ToArray();
            var auth_role_Mapping = db.Auth_Role_Mapping.SqlQuery(query, param).ToList();
            if (auth_role_Mapping.Count > 0)
                return true;
            else
                return false;
        }
        private async Task<bool> AuthorizeUserAsync(string Username)
        {
            this.ApplicationDbContext = new ApplicationDbContext();
            this.UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(this.ApplicationDbContext));
            var user = await UserManager.FindByNameAsync(Username).ConfigureAwait(continueOnCapturedContext: false);
            var roles = await UserManager.GetRolesAsync(user.Id).ConfigureAwait(continueOnCapturedContext: false);

            string last = roles.Last();
            int counter = 3;
            string partialSting = string.Empty;
            List<object> parameters = new List<object>();
            parameters.Add(_controller);
            parameters.Add(_action);
            parameters.Add(_area);
            foreach (string str in roles)
            {
                if (str.Contains(last))
                {
                    partialSting += "@p" + counter .ToString()+ ")))";
                    parameters.Add(str);
                }
                else
                {
                    partialSting += "@p" + counter.ToString() + ",";
                    parameters.Add(str);
                }

                counter++;
            }

            var query = @"SELECT 
                        [Extent1].[Id] AS [Id], 
                        [Extent1].[AuthAreaId] AS [AuthAreaId], 
                        [Extent1].[AuthControllerId] AS [AuthControllerId], 
                        [Extent1].[AuthActionId] AS [AuthActionId], 
                        [Extent1].[SocialRoleId] AS [SocialRoleId]
                        FROM      [dbo].[Auth_Role_Mapping] AS [Extent1]
                        INNER JOIN [dbo].[AuthControllers] AS [Extent2] ON [Extent1].[AuthControllerId] = [Extent2].[Id]
                        INNER JOIN [dbo].[AuthActions] AS [Extent3] ON [Extent1].[AuthActionId] = [Extent3].[Id]
                        INNER JOIN [dbo].[AuthAreas] AS [Extent4] ON [Extent1].[AuthAreaId] = [Extent4].[Id]
                        LEFT OUTER JOIN [dbo].[AspNetRoles] AS [Extent5] ON ([Extent1].[SocialRoleId] = [Extent5].[Id]) 
                        AND ([Extent5].[Discriminator] = N'SocialRole')
                        LEFT OUTER JOIN [dbo].[AspNetRoles] AS [Extent6] ON ([Extent1].[SocialRoleId] = [Extent6].[Id]) 
                        AND ([Extent6].[Discriminator] = N'SocialRole')
                        WHERE ([Extent2].[ControllerName] =  @p0)
	                    AND ([Extent3].[ActionName] =  @p1)
                        AND ([Extent4].[AreaName] =  @p2)
                        AND (([Extent5].[Name] in(  " + partialSting;
            object[] param = parameters.ToArray();
            var auth_role_Mapping = db.Auth_Role_Mapping.SqlQuery(query, param).ToList();
            if (auth_role_Mapping.Count>0)
                return true;
            else
                return false;
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            try
            {
                if (!httpContext.Request.IsAuthenticated)
                    return false;
                var routeData = httpContext.Request.RequestContext.RouteData;
                _controller = routeData.GetRequiredString("controller");
                _action = routeData.GetRequiredString("action");
                _area = routeData.DataTokens["area"].ToString();

                var IsAuth = AuthorizeUserAsync(httpContext.User.Identity.Name);
                if (IsAuth.Result)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectResult("Home");

            base.HandleUnauthorizedRequest(filterContext);
        }
    }
}