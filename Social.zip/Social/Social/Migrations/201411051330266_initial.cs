namespace Social.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Auth_Role_Mapping",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AuthAreaId = c.Int(nullable: false),
                        AuthControllerId = c.Int(nullable: false),
                        AuthActionId = c.Int(nullable: false),
                        SocialRoleId = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AuthActions", t => t.AuthActionId, cascadeDelete: true)
                .ForeignKey("dbo.AuthAreas", t => t.AuthAreaId, cascadeDelete: true)
                .ForeignKey("dbo.AuthControllers", t => t.AuthControllerId, cascadeDelete: true)
                .ForeignKey("dbo.AspNetRoles", t => t.SocialRoleId)
                .Index(t => t.AuthAreaId)
                .Index(t => t.AuthControllerId)
                .Index(t => t.AuthActionId)
                .Index(t => t.SocialRoleId);
            
            CreateTable(
                "dbo.AuthActions",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ActionName = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.AuthAreas",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AreaName = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.AuthControllers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ControllerName = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.AspNetRoles",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(),
                        Discriminator = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.Name, unique: true, name: "RoleNameIndex");
            
            CreateTable(
                "dbo.AspNetUserRoles",
                c => new
                    {
                        UserId = c.String(nullable: false, maxLength: 128),
                        RoleId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.UserId, t.RoleId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .ForeignKey("dbo.AspNetRoles", t => t.RoleId, cascadeDelete: true)
                .Index(t => t.UserId)
                .Index(t => t.RoleId);
            
            CreateTable(
                "dbo.Contact_Roles",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        RoleDescription = c.String(),
                        Role = c.Int(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Contacts",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Date_contact_From = c.DateTime(nullable: false),
                        Followerid = c.String(maxLength: 128),
                        Followedid = c.String(maxLength: 128),
                        RoleId = c.Int(nullable: false),
                        ApplicationUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Contact_Roles", t => t.RoleId, cascadeDelete: true)
                .ForeignKey("dbo.AspNetUsers", t => t.ApplicationUser_Id)
                .ForeignKey("dbo.AspNetUsers", t => t.Followedid)
                .ForeignKey("dbo.AspNetUsers", t => t.Followerid)
                .Index(t => t.Followerid)
                .Index(t => t.Followedid)
                .Index(t => t.RoleId)
                .Index(t => t.ApplicationUser_Id);
            
            CreateTable(
                "dbo.AspNetUsers",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        IsActive = c.Boolean(nullable: false),
                        Address = c.String(),
                        City = c.String(),
                        State = c.String(),
                        FirstName = c.String(),
                        PrefferedName = c.String(),
                        LastName = c.String(),
                        PostalCode = c.String(),
                        Email = c.String(maxLength: 256),
                        EmailConfirmed = c.Boolean(nullable: false),
                        PasswordHash = c.String(),
                        SecurityStamp = c.String(),
                        PhoneNumber = c.String(),
                        PhoneNumberConfirmed = c.Boolean(nullable: false),
                        TwoFactorEnabled = c.Boolean(nullable: false),
                        LockoutEndDateUtc = c.DateTime(),
                        LockoutEnabled = c.Boolean(nullable: false),
                        AccessFailedCount = c.Int(nullable: false),
                        UserName = c.String(nullable: false, maxLength: 256),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.UserName, unique: true, name: "UserNameIndex");
            
            CreateTable(
                "dbo.AspNetUserClaims",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.String(nullable: false, maxLength: 128),
                        ClaimType = c.String(),
                        ClaimValue = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.JobApplications",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ApplicatioDate = c.DateTime(nullable: false),
                        Seen = c.Boolean(nullable: false),
                        SeenDate = c.DateTime(nullable: false),
                        IsSelected = c.Boolean(nullable: false),
                        IsShortListed = c.Boolean(nullable: false),
                        JobId = c.Int(nullable: false),
                        UserId = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId)
                .ForeignKey("dbo.PublicJobs", t => t.JobId, cascadeDelete: true)
                .Index(t => t.JobId)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.PublicJobs",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        JobTitle = c.String(),
                        JobDetails = c.String(),
                        JobReq1 = c.String(),
                        JobReq2 = c.String(),
                        JobReq3 = c.String(),
                        JobReq4 = c.String(),
                        JobReq5 = c.String(),
                        JobReq6 = c.String(),
                        JobReq7 = c.String(),
                        JobReq8 = c.String(),
                        JobReq9 = c.String(),
                        PublishDate = c.DateTime(nullable: false),
                        ExpirayDate = c.DateTime(nullable: false),
                        JobCountry = c.String(),
                        JobState = c.String(),
                        JobCity = c.String(),
                        JobAddressLine1 = c.String(),
                        JobAddressLine2 = c.String(),
                        JobZIPCode = c.String(),
                        JobCompany = c.String(),
                        JobDepartment = c.String(),
                        JobJoiningDate = c.String(),
                        AdminId = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.AdminId)
                .Index(t => t.AdminId);
            
            CreateTable(
                "dbo.AspNetUserLogins",
                c => new
                    {
                        LoginProvider = c.String(nullable: false, maxLength: 128),
                        ProviderKey = c.String(nullable: false, maxLength: 128),
                        UserId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.LoginProvider, t.ProviderKey, t.UserId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.Messages",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        MessageBody = c.String(),
                        MessageSubject = c.String(),
                        SentTime = c.DateTime(nullable: false),
                        SeenTime = c.DateTime(nullable: false),
                        Seen = c.Boolean(nullable: false),
                        FromId = c.String(maxLength: 128),
                        ToId = c.String(maxLength: 128),
                        ApplicationUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.AspNetUsers", t => t.FromId)
                .ForeignKey("dbo.AspNetUsers", t => t.ToId)
                .ForeignKey("dbo.AspNetUsers", t => t.ApplicationUser_Id)
                .Index(t => t.FromId)
                .Index(t => t.ToId)
                .Index(t => t.ApplicationUser_Id);
            
            CreateTable(
                "dbo.Photos",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        PhotoTitle = c.String(),
                        PhotoName = c.String(),
                        ImageMimeType = c.Int(),
                        Imagethumbnail = c.Binary(),
                        ImageData = c.Binary(),
                        ProfilePhoto = c.Boolean(nullable: false),
                        AddedDate = c.DateTime(nullable: false),
                        UserId = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.WallPosts",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        PostData = c.String(),
                        IsActive = c.Boolean(nullable: false),
                        PostDate = c.DateTime(nullable: false),
                        Privacy = c.Int(),
                        Photopath = c.String(),
                        UserId = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId)
                .Index(t => t.UserId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUserRoles", "RoleId", "dbo.AspNetRoles");
            DropForeignKey("dbo.Contacts", "Followerid", "dbo.AspNetUsers");
            DropForeignKey("dbo.Contacts", "Followedid", "dbo.AspNetUsers");
            DropForeignKey("dbo.WallPosts", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserRoles", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Photos", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Messages", "ApplicationUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.Messages", "ToId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Messages", "FromId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserLogins", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.JobApplications", "JobId", "dbo.PublicJobs");
            DropForeignKey("dbo.PublicJobs", "AdminId", "dbo.AspNetUsers");
            DropForeignKey("dbo.JobApplications", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Contacts", "ApplicationUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserClaims", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Contacts", "RoleId", "dbo.Contact_Roles");
            DropForeignKey("dbo.Auth_Role_Mapping", "SocialRoleId", "dbo.AspNetRoles");
            DropForeignKey("dbo.Auth_Role_Mapping", "AuthControllerId", "dbo.AuthControllers");
            DropForeignKey("dbo.Auth_Role_Mapping", "AuthAreaId", "dbo.AuthAreas");
            DropForeignKey("dbo.Auth_Role_Mapping", "AuthActionId", "dbo.AuthActions");
            DropIndex("dbo.WallPosts", new[] { "UserId" });
            DropIndex("dbo.Photos", new[] { "UserId" });
            DropIndex("dbo.Messages", new[] { "ApplicationUser_Id" });
            DropIndex("dbo.Messages", new[] { "ToId" });
            DropIndex("dbo.Messages", new[] { "FromId" });
            DropIndex("dbo.AspNetUserLogins", new[] { "UserId" });
            DropIndex("dbo.PublicJobs", new[] { "AdminId" });
            DropIndex("dbo.JobApplications", new[] { "UserId" });
            DropIndex("dbo.JobApplications", new[] { "JobId" });
            DropIndex("dbo.AspNetUserClaims", new[] { "UserId" });
            DropIndex("dbo.AspNetUsers", "UserNameIndex");
            DropIndex("dbo.Contacts", new[] { "ApplicationUser_Id" });
            DropIndex("dbo.Contacts", new[] { "RoleId" });
            DropIndex("dbo.Contacts", new[] { "Followedid" });
            DropIndex("dbo.Contacts", new[] { "Followerid" });
            DropIndex("dbo.AspNetUserRoles", new[] { "RoleId" });
            DropIndex("dbo.AspNetUserRoles", new[] { "UserId" });
            DropIndex("dbo.AspNetRoles", "RoleNameIndex");
            DropIndex("dbo.Auth_Role_Mapping", new[] { "SocialRoleId" });
            DropIndex("dbo.Auth_Role_Mapping", new[] { "AuthActionId" });
            DropIndex("dbo.Auth_Role_Mapping", new[] { "AuthControllerId" });
            DropIndex("dbo.Auth_Role_Mapping", new[] { "AuthAreaId" });
            DropTable("dbo.WallPosts");
            DropTable("dbo.Photos");
            DropTable("dbo.Messages");
            DropTable("dbo.AspNetUserLogins");
            DropTable("dbo.PublicJobs");
            DropTable("dbo.JobApplications");
            DropTable("dbo.AspNetUserClaims");
            DropTable("dbo.AspNetUsers");
            DropTable("dbo.Contacts");
            DropTable("dbo.Contact_Roles");
            DropTable("dbo.AspNetUserRoles");
            DropTable("dbo.AspNetRoles");
            DropTable("dbo.AuthControllers");
            DropTable("dbo.AuthAreas");
            DropTable("dbo.AuthActions");
            DropTable("dbo.Auth_Role_Mapping");
        }
    }
}
