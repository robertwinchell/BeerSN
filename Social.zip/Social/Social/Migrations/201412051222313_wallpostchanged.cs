namespace Social.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class wallpostchanged : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.WallPosts", "postimageID", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.WallPosts", "postimageID");
        }
    }
}
