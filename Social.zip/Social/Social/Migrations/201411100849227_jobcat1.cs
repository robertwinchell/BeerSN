namespace Social.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class jobcat1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.PublicJobs", "JobCategory_Id", "dbo.JobCategories");
            DropIndex("dbo.PublicJobs", new[] { "JobCategory_Id" });
            DropColumn("dbo.PublicJobs", "JobCategoryId");
            RenameColumn(table: "dbo.PublicJobs", name: "JobCategory_Id", newName: "JobCategoryId");
            AlterColumn("dbo.PublicJobs", "JobCategoryId", c => c.Int(nullable: false));
            AlterColumn("dbo.PublicJobs", "JobCategoryId", c => c.Int(nullable: false));
            CreateIndex("dbo.PublicJobs", "JobCategoryId");
            AddForeignKey("dbo.PublicJobs", "JobCategoryId", "dbo.JobCategories", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.PublicJobs", "JobCategoryId", "dbo.JobCategories");
            DropIndex("dbo.PublicJobs", new[] { "JobCategoryId" });
            AlterColumn("dbo.PublicJobs", "JobCategoryId", c => c.Int());
            AlterColumn("dbo.PublicJobs", "JobCategoryId", c => c.String());
            RenameColumn(table: "dbo.PublicJobs", name: "JobCategoryId", newName: "JobCategory_Id");
            AddColumn("dbo.PublicJobs", "JobCategoryId", c => c.String());
            CreateIndex("dbo.PublicJobs", "JobCategory_Id");
            AddForeignKey("dbo.PublicJobs", "JobCategory_Id", "dbo.JobCategories", "Id");
        }
    }
}
