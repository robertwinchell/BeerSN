namespace Social.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class jobcat : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.JobCategories",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        JobCatName = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.PublicJobs", "JobReq10", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity1", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity2", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity3", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity4", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity5", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity6", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity7", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity8", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity9", c => c.String());
            AddColumn("dbo.PublicJobs", "JobOppertunity10", c => c.String());
            AddColumn("dbo.PublicJobs", "AboutCompany", c => c.String());
            AddColumn("dbo.PublicJobs", "JobCategoryId", c => c.String());
            AddColumn("dbo.PublicJobs", "JobCategory_Id", c => c.Int());
            CreateIndex("dbo.PublicJobs", "JobCategory_Id");
            AddForeignKey("dbo.PublicJobs", "JobCategory_Id", "dbo.JobCategories", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.PublicJobs", "JobCategory_Id", "dbo.JobCategories");
            DropIndex("dbo.PublicJobs", new[] { "JobCategory_Id" });
            DropColumn("dbo.PublicJobs", "JobCategory_Id");
            DropColumn("dbo.PublicJobs", "JobCategoryId");
            DropColumn("dbo.PublicJobs", "AboutCompany");
            DropColumn("dbo.PublicJobs", "JobOppertunity10");
            DropColumn("dbo.PublicJobs", "JobOppertunity9");
            DropColumn("dbo.PublicJobs", "JobOppertunity8");
            DropColumn("dbo.PublicJobs", "JobOppertunity7");
            DropColumn("dbo.PublicJobs", "JobOppertunity6");
            DropColumn("dbo.PublicJobs", "JobOppertunity5");
            DropColumn("dbo.PublicJobs", "JobOppertunity4");
            DropColumn("dbo.PublicJobs", "JobOppertunity3");
            DropColumn("dbo.PublicJobs", "JobOppertunity2");
            DropColumn("dbo.PublicJobs", "JobOppertunity1");
            DropColumn("dbo.PublicJobs", "JobReq10");
            DropTable("dbo.JobCategories");
        }
    }
}
