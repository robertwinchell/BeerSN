namespace Social.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class update : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.PublicJobs", "JobJoiningDate", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.PublicJobs", "JobJoiningDate", c => c.String());
        }
    }
}
