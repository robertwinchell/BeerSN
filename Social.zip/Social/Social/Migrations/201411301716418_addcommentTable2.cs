namespace Social.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addcommentTable2 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.SocialComments",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        PostDate = c.DateTime(nullable: false),
                        postImageID = c.String(),
                        CommentBody = c.String(),
                        Authorid = c.String(maxLength: 128),
                        WallPostid = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.Authorid)
                .ForeignKey("dbo.WallPosts", t => t.WallPostid, cascadeDelete: true)
                .Index(t => t.Authorid)
                .Index(t => t.WallPostid);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.SocialComments", "WallPostid", "dbo.WallPosts");
            DropForeignKey("dbo.SocialComments", "Authorid", "dbo.AspNetUsers");
            DropIndex("dbo.SocialComments", new[] { "WallPostid" });
            DropIndex("dbo.SocialComments", new[] { "Authorid" });
            DropTable("dbo.SocialComments");
        }
    }
}
