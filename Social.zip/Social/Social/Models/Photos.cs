﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public class Photos
    {
        public int Id { get; set; }
        public string PhotoTitle { get; set; }
        public string PhotoName { get; set; }
        public int? ImageMimeType { get; set; }
        public byte[] Imagethumbnail { get; set; }
        [Display(Name = "Image")]
        public byte[] ImageData { get; set; }
        public bool ProfilePhoto { get; set; }
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime AddedDate { get; set; }
        public string UserId { get; set; }
        [ForeignKey("UserId")]
        public ApplicationUser ApplicationUser { get; set; }



    }
}