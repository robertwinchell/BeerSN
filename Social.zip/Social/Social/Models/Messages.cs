﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public class Messages
    {
        public int ID { get; set; }

        public string MessageBody { get; set; }

        public string MessageSubject { get; set; }

        public DateTime SentTime { get; set; }
        public DateTime SeenTime { get; set; }
        public bool Seen { get; set; }

        public string FromId { get; set; }
        [ForeignKey("FromId")]
        public ApplicationUser From { get; set; }

        public string ToId { get; set; }
        [ForeignKey("ToId")]
        public ApplicationUser To { get; set; }

        public IEnumerable<Contact_Roles> Contact_Roles { get; set; }



    }
}