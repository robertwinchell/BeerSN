﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public class SocialComments
    {
        [Key]
        public int Id { get; set; }
        public DateTime PostDate { get; set; }
        public string postImageID { get; set; }
        public string CommentBody { get; set; }

        public string Authorid { get; set; }
        [ForeignKey("Authorid")]
        public ApplicationUser Author { get; set; }


        public int WallPostid { get; set; }
        [ForeignKey("WallPostid")]
        public WallPosts WallPost { get; set; }
    }
}