﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public class AuthArea
    {
        public int Id { get; set; }
        public string AreaName { get; set; }

        public IEnumerable<Auth_Role_Mapping> Auth_Role_Mapping { get; set; }
    }
    public class AuthController
    {
        public int Id { get; set; }
        public string ControllerName { get; set; }

        public IEnumerable<Auth_Role_Mapping> Auth_Role_Mapping { get; set; }
    }
    public class AuthAction
    {
        public int Id { get; set; }
        public string ActionName { get; set; }
        public IEnumerable<Auth_Role_Mapping> Auth_Role_Mapping { get; set; }
    }
    public class Auth_Role_Mapping
    {
        [Key]
        public int Id { get; set; }

        public int AuthAreaId { get; set; }
        public virtual AuthArea AuthArea { get; set; }


        public int AuthControllerId { get; set; }
        public virtual AuthController AuthController { get; set; }


        public int AuthActionId { get; set; }
        public virtual AuthAction AuthAction { get; set; }

        public string SocialRoleId { get; set; }

        public virtual SocialRole SocialRole { get; set; }
    }
}