﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public class JobApplications
    {
        public int Id { get; set; }
        public DateTime ApplicatioDate { get; set; }
        public bool Seen { get; set; }
        public DateTime SeenDate { get; set; }
        public bool IsSelected { get; set; }
        public bool IsShortListed { get; set; }


        public byte[] AttachedResume { get; set; }
        public string contenttype { get; set; }
        public string ResumeTitle { get; set; }
        public string PastedResume { get; set; }
     
        public int JobId { get; set; }
        [ForeignKey("JobId")]
        public  virtual PublicJobs PublicJobs { get; set; }

        public string UserId { get; set; }
        [ForeignKey("UserId")]
        public virtual ApplicationUser ApplicationUser { get; set; }

    }
}