﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public class JobCategory
    {
        public int Id { get; set; }
        public String JobCatName { get; set; }
        public DateTime LastPostDate { get; set; }

        public virtual ICollection<PublicJobs> PublicJobs { get; set; }

    }
}