﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Configuration;



namespace Social.Models
{
    public class EmailService
    {
        public static int SendEmail(IdentityMessage message)
        {




            //MailMessage mail = new MailMessage();
            //SmtpClient SmtpServer = new SmtpClient(WebConfigurationManager.AppSettings["SmtpClient"].ToString());
            //    //rootWebConfig1.AppSettings.Settings["SmtpClient"].Value);

            //mail.From = new MailAddress(WebConfigurationManager.AppSettings["SmtpFrom"].ToString());
            //    //rootWebConfig1.AppSettings.Settings["SmtpFrom"].Value);
            //mail.To.Add(message.Destination);
            //mail.Subject = message.Subject;
            //mail.Body = message.Body;

            //SmtpServer.Port = Convert.ToInt32(WebConfigurationManager.AppSettings["SmtpPort"].ToString());
            //  //  rootWebConfig1.AppSettings.Settings["SmtpPort"].Value);
            //SmtpServer.Credentials = new System.Net.NetworkCredential(
            //    WebConfigurationManager.AppSettings["SmtpUserName"].ToString(),
            //    WebConfigurationManager.AppSettings["SmtpPassword"].ToString());
            //    //rootWebConfig1.AppSettings.Settings["SmtpUserName"].Value,
            //    //rootWebConfig1.AppSettings.Settings["SmtpPassword"].Value);
            //SmtpServer.EnableSsl = true;

            //SmtpServer.Send(mail);

            //return 1;






            SmtpClient ss = new SmtpClient();

            try
            {
                ss.Host = WebConfigurationManager.AppSettings["SmtpClient"].ToString();
                ss.Port = 25;
                ss.Timeout = 10000;
                ss.DeliveryMethod = SmtpDeliveryMethod.Network;
                ss.UseDefaultCredentials = false;
                ss.Credentials = new NetworkCredential(WebConfigurationManager.AppSettings["SmtpUserName"].ToString()
                    , WebConfigurationManager.AppSettings["SmtpPassword"].ToString());

                MailMessage mailMsg = new MailMessage(WebConfigurationManager.AppSettings["SmtpFrom"].ToString(),
                    message.Destination,
                    message.Subject, message.Body);
                mailMsg.IsBodyHtml = true;
                mailMsg.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                ss.Send(mailMsg);

                return 1;
                //Console.WriteLine("Sent email");
                //Console.ReadKey();
            }


            catch (Exception ex)
            {
                return -1;
            }
        }
    }
}