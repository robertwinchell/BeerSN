﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public class Contacts
    {
        [Key]
        public int Id { get; set; }
        public DateTime Date_contact_From { get; set; }


        public string Followerid { get; set; }
        [ForeignKey("Followerid")]
        public ApplicationUser Follower { get; set; }


        
        public string Followedid { get; set; }
        [ForeignKey("Followedid")]
        public ApplicationUser Followed { get; set; }

        public int RoleId { get; set; }
        [ForeignKey("RoleId")]
        public Contact_Roles Contact_Roles { get; set; }



    }
}