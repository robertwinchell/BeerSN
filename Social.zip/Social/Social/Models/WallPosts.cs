﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public enum Privacy
    {
        Public,
        OnlywithFrineds,
        OnlywithFamily,
        OnlyMe
    }

    public class WallPosts
    {
        [Key]
        public int Id { get; set; }
        public string PostData { get; set; }
        public bool IsActive { get; set; }
        public DateTime PostDate { get; set; }
        public Privacy? Privacy { get; set; }
        public string Photopath { get; set; }
        public string postimageID { get; set; }
        public virtual ICollection<SocialComments> SocialComments { get; set; }

        public string UserId { get; set; }
        [ForeignKey("UserId")]
        public ApplicationUser ApplicationUser { get; set; }


    }
}