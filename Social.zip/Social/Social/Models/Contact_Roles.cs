﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public enum Role
    {
        Relative,
        Friend,
        Partner,
        Collegue
    }
    public class Contact_Roles
    {
        public int Id { get; set; }
        public string RoleDescription { get; set; }
        public Role? Role { get; set; }

        public virtual IEnumerable<Contacts> Contacts { get; set; }
    }
}