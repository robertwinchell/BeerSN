﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Social.Areas.JobAdmin.Models;
using Social.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;

namespace IdentitySample.Models
{
    public enum Gender
    {
        Male,
        Female,
        Hidden
    }
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser
    {
        public bool IsActive { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }

        public string FirstName { get; set; }
        public string PrefferedName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public Gender? Gender { get; set; }
        public string JobTitle { get; set; }

        // Use a sensible display name for views:
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }
        // Concatenate the Full Name info
        public string FullName
        {
            get
            {
                string FirstName =
                    string.IsNullOrWhiteSpace(this.FirstName) ? "" : this.FirstName;
                string PrefferedName =
                    string.IsNullOrWhiteSpace(this.PrefferedName) ? "" : this.PrefferedName;
                string LastName =
                    string.IsNullOrWhiteSpace(this.LastName) ? "" : this.LastName;
                return string
                    .Format("{0} {1} {2}", FirstName, PrefferedName, LastName);
            }
        }
        // Concatenate the address info for display in tables and such:
        public string DisplayAddress
        {
            get
            {
                string dspAddress =
                    string.IsNullOrWhiteSpace(this.Address) ? "" : this.Address;
                string dspCity =
                    string.IsNullOrWhiteSpace(this.City) ? "" : this.City;
                string dspState =
                    string.IsNullOrWhiteSpace(this.State) ? "" : this.State;
                string dspPostalCode =
                    string.IsNullOrWhiteSpace(this.PostalCode) ? "" : this.PostalCode;

                return string
                    .Format("{0} ,{1}, {2} {3}", dspAddress, dspCity, dspState, dspPostalCode);
            }
        }
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
        public ApplicationUser() { }
        public virtual ICollection<Messages> Messages { get; set; }
        public virtual ICollection<Photos> Photos { get; set; }
        public virtual ICollection<Contacts> Contacts { get; set; }
        public virtual ICollection<WallPosts> WallPosts { get; set; }
        public virtual ICollection<JobApplications> JobApplications { get; set; }
        public virtual ICollection<SocialComments> SocialComments { get; set; }

    }


    public class SocialRole : IdentityRole
    {
        public SocialRole() : base() { }
        public SocialRole(string name) : base(name) { }
        public string Description { get; set; }
        public IEnumerable<Auth_Role_Mapping> Auth_Role_Mapping { get; set; }
    }
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        //static ApplicationDbContext()
        //{
        //    // Set the database intializer which is run once during application start
        //    // This seeds the database with admin user credentials and admin role
        //    Database.SetInitializer<ApplicationDbContext>(new ApplicationDbInitializer());
        //}

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
        //Custom Tables
        public DbSet<Messages> Messages { get; set; }
        public DbSet<Contacts> Contacts { get; set; }
        public DbSet<Contact_Roles> Contact_Roles { get; set; }
        public DbSet<Photos> Photos { get; set; }
        public DbSet<WallPosts> WallPosts { get; set; }
        public DbSet<JobApplications> JobApplications { get; set; }
        public DbSet<PublicJobs> PublicJobs { get; set; }
        public DbSet<Auth_Role_Mapping> Auth_Role_Mapping { get; set; }
        public DbSet<AuthArea> AuthArea { get; set; }
        public DbSet<AuthController> AuthController { get; set; }
        public DbSet<AuthAction> AuthAction { get; set; }
        public DbSet<JobCategory> JobCategory { get; set; }
        public DbSet<SocialComments> SocialComments { get; set; }
       // public System.Data.Entity.DbSet<IdentitySample.Models.ApplicationUser> Users { get; set; }

        //public System.Data.Entity.DbSet<IdentitySample.Models.ApplicationUser> ApplicationUsers { get; set; }

        
    }
}