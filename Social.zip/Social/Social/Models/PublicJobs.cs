﻿using IdentitySample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Social.Models
{
    public class PublicJobs
    {
        public int Id { get; set; }
        [DisplayName("Title")]
        public string JobTitle { get; set; }
        [DisplayName("Detail 1")]
        public string JobDetails { get; set; }
        [DisplayName("Detail 2")]
        public string JobReq1 { get; set; }
        [DisplayName("Detail 3")]
        public string JobReq2 { get; set; }
        public string JobReq3 { get; set; }
        public string JobReq4 { get; set; }
        public string JobReq5 { get; set; }
        public string JobReq6 { get; set; }
        public string JobReq7 { get; set; }
        public string JobReq8 { get; set; }
        public string JobReq9 { get; set; }
        public string JobReq10 { get; set; }


        public string JobOppertunity1 { get; set; }
        public string JobOppertunity2 { get; set; }
        public string JobOppertunity3 { get; set; }
        public string JobOppertunity4 { get; set; }
        public string JobOppertunity5 { get; set; }
        public string JobOppertunity6 { get; set; }
        public string JobOppertunity7 { get; set; }
        public string JobOppertunity8 { get; set; }
        public string JobOppertunity9 { get; set; }
        public string JobOppertunity10 { get; set; }
        [DisplayName("Effective Date")]
        public DateTime PublishDate { get; set; }
        [DisplayName("Expiry Date")]
        public DateTime ExpirayDate { get; set; }
        [DisplayName("Country")]
        public string JobCountry { get; set; }
        [DisplayName("State")]
        public string JobState { get; set; }
        [DisplayName("City")]
        public string JobCity { get; set; }
        [DisplayName("AddressLine1")]
        public string JobAddressLine1 { get; set; }
        [DisplayName("AddressLine2")]
        public string JobAddressLine2 { get; set; }
        [DisplayName("ZIPCode")]
        public string JobZIPCode { get; set; }
        [DisplayName("Company Name")]
        public string JobCompany { get; set; }
        [DisplayName("About Company")]
        public string AboutCompany { get; set; }
        [DisplayName("Department")]
        public string JobDepartment { get; set; }
        [DisplayName("Joining Date")]
        public DateTime JobJoiningDate { get; set; }

        public string AdminId { get; set; }
        [ForeignKey("AdminId")]
        public virtual ApplicationUser ApplicationUser { get; set; }


        public int JobCategoryId { get; set; }
        public virtual JobCategory JobCategory { get; set; }

        public virtual ICollection<JobApplications> JobApplications { get; set; }
    }
}